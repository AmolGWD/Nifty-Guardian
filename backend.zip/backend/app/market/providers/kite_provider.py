import os
from pathlib import Path

from dotenv import load_dotenv
from kiteconnect import KiteConnect

from app.auth.token_store import token_store
from app.market.providers.base_provider import BaseMarketProvider

BASE_DIR = Path(__file__).resolve().parents[3]
load_dotenv(BASE_DIR / ".env")


class KiteProvider(BaseMarketProvider):

    def __init__(self):

        self.api_key = os.getenv("KITE_API_KEY")

        self.kite = KiteConnect(api_key=self.api_key)

    def get_market_data(self):

        access_token = token_store.access_token()

        if access_token is None:
            raise Exception("Please login to Kite first.")

        self.kite.set_access_token(access_token)

        quote = self.kite.quote(["NSE:NIFTY 50"])["NSE:NIFTY 50"]

        ohlc = quote["ohlc"]

        last = quote["last_price"]

        previous_close = ohlc["close"]

        change = round(last - previous_close, 2)

        return {

            "symbol": "NIFTY 50",

            "price": last,

            "change": change,

            "open": ohlc["open"],

            "high": ohlc["high"],

            "low": ohlc["low"],

            "previous_close": previous_close,

            "market_mood": "Bullish" if change >= 0 else "Bearish",

            "trend": "Uptrend" if change >= 0 else "Downtrend",

            "volatility": "Medium",

            "pcr": 1.00,

            "oi_bias": "Neutral",

            "last_refresh": quote["timestamp"].strftime("%H:%M:%S")

        }


kite_provider = KiteProvider()